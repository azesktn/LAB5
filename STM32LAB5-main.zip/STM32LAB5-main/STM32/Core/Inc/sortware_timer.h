/*
 * sortware_timer.h
 *
 *  Created on: Nov 15, 2025
 *      Author: PHITRUONGPC
 */

#ifndef INC_SORTWARE_TIMER_H_
#define INC_SORTWARE_TIMER_H_

void setTimer(int index, int duration);
int co(int index);
void timerRun();


#endif /* INC_SORTWARE_TIMER_H_ */
